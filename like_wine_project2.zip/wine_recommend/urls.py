from django.urls import path
from . import views


urlpatterns = [

    path('', views.index, name='index'),

    path('recommend_name/', views.recommend_name, name="recommend_name"),#희정수정
    path('recommend_name_result/', views.recommend_name_result, name="recommend_name_result"),
    path('recommend_category/', views.recommend_category, name="recommend_category"),#희정수정
    path('recommend_category_result/', views.recommend_category_result, name="recommend_category_result"),
]
