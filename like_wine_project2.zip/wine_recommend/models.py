from django.db import models

# # Create your models here.
class wine_data(models.Model):
    price_1	= models.FloatField(default=0)
    alcohol_1=models.FloatField()
    rev_alcohol_1=models.FloatField()
    name=models.CharField(max_length=100)
    price=models.FloatField()
    score=models.FloatField()
    winery=models.CharField(max_length=100)
    grapes=models.CharField(max_length=100)
    country=models.CharField(max_length=100)
    region=models.CharField(max_length=100)
    alcohol=models.FloatField()
    foods=models.CharField(max_length=100)
    wine_id=models.IntegerField(default=0)
    # re=models.CharField(max_length=100)
    rev_alcohol=models.FloatField()

    # class Meta:
    #     db_table = "minmaxscaling_wine.csv"

    def __str__(self):
        return self.name
