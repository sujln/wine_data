import re
import nltk
from nltk.corpus import stopwords
from collections import Counter

import pandas as pd
import string

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

#
# country_select = df['country'].value_counts().head(15).keys().to_list()
# grape_select = df['grapes'].value_counts().head(15).keys().to_list()

#불용어 제거
nltk.download('stopwords')
#from nltk.corpus import stopwords
stopwords = nltk.corpus.stopwords.words('english')


def cosine_func2(df,col_name,sim):

    #정규 표현식으로 영문만 남음
    only_english  = [ re.sub('[^a-zA-Z]', ' ',sentence).lower() for sentence in df[col_name]]
    #토큰만들기
    col_tokenized = [ nltk.word_tokenize(item) for item in only_english ]
    #불용어 빼기
    no_stopwords = [ i for i in col_tokenized if i not in stopwords]
    #다시 합쳐주기
    final_review = [ ' '.join(item) for item in no_stopwords ]
#     final_review = nltk.Text(no_stopwords) # corpus 생성

    #Tfidf
    tfidf_vect = TfidfVectorizer()
    feature_vect = tfidf_vect.fit_transform(final_review)
    if col_name == 'foods':
        my_vect = tfidf_vect.transform(sim[0])
    else:
        my_vect = tfidf_vect.transform(sim[1])

    #코사인 유사도 분석 => 사용자가 입력한 와인과 전체
    similarity_simple_pair = cosine_similarity(my_vect, feature_vect)
    result_list = similarity_simple_pair.tolist()[0]
    df[f'{col_name}_result'] = result_list

    return df

def weight_cal2(num):
    if num == 1:
        w = 2.0
    elif num == 2 :
        w=1.5
    else:
        w=1
    return w
