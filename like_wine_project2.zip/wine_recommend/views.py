from django.shortcuts import render, redirect
from django.http import HttpResponse
import pandas as pd
from .wine_model1 import cosine_func1, weight_cal1
from .wine_model2 import cosine_func2, weight_cal2
import string
import requests
from bs4 import BeautifulSoup
import re
import numpy as np

# Create your views here.
def index(request):
    return render(request, 'wine_recommend/index.html',{})


# Wine Recommendation by Name
def recommend_name(request):

    file_path = './wine_recommend/data/wine_newname_final.csv'
    wind_data_df = pd.read_csv(file_path)

    wine_name_list_raw = list(wind_data_df['name'])
    wine_name_list = []

    for name in wine_name_list_raw:
        if type(name) == float:
            pass
        else:
            wine_name_list.append(re.sub(r"[^a-zA-Z0-9\s]", "", name))


    context = {'wine_name_list':wine_name_list}
    return render(request, 'wine_recommend/recommend_name.html',context)


def recommend_name_result(request):

    file_path = './wine_recommend/data/wine_newname_final.csv'
    df = pd.read_csv(file_path)

    if request.method == 'POST':
        #와인이름 받기
        wine_name = str(request.POST['my_wine'])
        new_name = string.capwords(wine_name)
        wine_index =df[df['name'].str.contains(new_name)==True].index[0]

        #선호도 받기
        my_alcohol = request.POST['how_alcohol']
        my_price = request.POST['how_price']

        #가중치 받기
        price_w = float(request.POST['price']) if request.POST['price'] != '' else 0.1
        score_w = float(request.POST['score']) if request.POST['score'] != '' else 0.1
        alcohol_w = float(request.POST['alcohol']) if request.POST['alcohol'] != '' else 0.1
        food_w = float(request.POST['food']) if request.POST['food'] != '' else 0.1
        review_w = float(request.POST['review']) if request.POST['review'] != '' else 0.1

#       데이터프레임에 유사도 추가
        df = cosine_func1(df,'foods',wine_index)
        df = cosine_func1(df,'re',wine_index)

        result_arr = []
        for column in df.columns.values:
            if (df[column].dtype == 'float64') |  (df[column].dtype == 'int64'):
                if(column != 'wine_id'):
                    result_arr.append(column)

        df_result_weight = df[result_arr].copy()


        result= weight_cal1(df,df_result_weight,price_w,score_w,alcohol_w,food_w,review_w,my_alcohol,my_price)

        result_name = result['name'].to_list()
        result_price = result['price'].to_list()
        result_winery = result['winery'].to_list()
        result_alcohol = np.round(result['alcohol'].to_list(),1)  # 도수 반올림
        result_url = result['url'].to_list()


        #사진 url 뽑아오기
        img_url=[]
        headers = {'User-Agent': 'Mozilla/5.0'}
        for url in result_url :
            web = requests.get(url, headers=headers).content
            source = BeautifulSoup(web, 'html.parser')
            img_url.append(source.find_all('img',{'class':'image'})[0]['src'])



        result_data = zip(result_name,result_winery,result_price,result_alcohol,img_url,result_url)
        context = {'result_data': result_data}



        return render(request, 'wine_recommend/recommend_name_result.html',context)

    else:
        a = 'fail'
        context = {'a':a}
        return render(request,'wine_recommend/recommend_name_result.html',context)
    # return render(request, "wine_name.html")





# Wine Recommendation by Category

def recommend_category(request):
    file_path = './wine_recommend/data/wine_newname_final.csv'
    df = pd.read_csv(file_path)

# 나라 리스트
    country_select = df['country'].value_counts().head(15).keys().to_list()
# 포도 품종 리스트
    grape_select = df['grapes'].value_counts().head(15).keys().to_list()
    vivino_grapes = ['Cabernet Sauvignon', 'Merlot', 'Chardonnay', 'Pinot Noir', 'Malbec',
                    'Sauvignon Blanc', 'Shiraz/Syrah', 'Zinfandel', 'Nebbiolo', 'Sangiovese',
                    'Pinot Grigio', 'Riesling', 'Chenin Blanc', 'Moscato', 'Albarino']
    for i in range(len(vivino_grapes)):
        if vivino_grapes[i] not in grape_select:
            grape_select.append(vivino_grapes[i])
# 음식 리스트
    my_food = df['foods'].unique()
    food_list=[]
    for i in range(len(my_food)):
        for j in range(len(my_food[i].replace("]","").replace("[","").replace("'","").split(","))):
            food_list.append(my_food[i].replace("]","").replace("[","").replace("'","").split(",")[j].strip())
    food_result = pd.DataFrame(food_list)
    food_result = pd.Series(food_result[0].unique())
    food_select = food_result[(food_result.str.contains("\(")==False) & (food_result.str.contains("\)")==False)].to_list()
    food_select.append("Game(deer, venison)")
    food_select.append("Rich fish(salmon, tuna etc)")


    context = {'country_select': country_select, 'grape_select': grape_select,'food_select':food_select}


    return render(request, "wine_recommend/recommend_category.html",context)

def recommend_category_result(request):

    file_path = './wine_recommend/data/wine_newname_final.csv'
    df = pd.read_csv(file_path)

    if request.method == 'POST':

        #알콜도수 받기
        alcohol_min =float( request.POST['alcohol_min']) if request.POST['alcohol_min'] != '' else 0
        alcohol_max = float(request.POST['alcohol_max']) if request.POST['alcohol_max'] != '' else 50
        # 가격 받기
        price_min = float(request.POST['price_min']) if request.POST['price_min'] != '' else 0
        price_max = float(request.POST['price_max']) if request.POST['price_max'] != '' else 10000
        # 같이먹을 음식 받기
        food_name = request.POST.getlist('go_with_food')
        # 리뷰받기
        review_tagname = request.POST['review_tagname'] if request.POST['review_tagname'] != '' else 'good'
        # 포도 품종
        grape_name = request.POST['grape_filter']
        #선호 나라
        country_name = request.POST['country_filter']
        #선호도 받기
        my_score = int(request.POST['priority_score'])
        my_food = int(request.POST['priority_food'])
        my_review = int(request.POST['priority_review'])

        df = df[(df['alcohol'] >= alcohol_min) & (df['alcohol'] <= alcohol_max)]
        df = df[(df['price'] >= price_min) & (df['price'] <= price_max) ]

        if grape_name != "":
            df = df[(df['grapes'] == grape_name )]
        if country_name != "":
            df = df[(df['country'] == country_name )]

        if food_name == []:
            food_name = ['beef']

        similar = [food_name,review_tagname.split(" ")]
        print(similar)

        #데이터프레임에 유사도 추가
        df = cosine_func2(df,'foods',similar)
        df = cosine_func2(df,'re',similar)

        result_arr=["s_score","s_alcohol","s_price","foods_result","re_result"]

        df_result_weight = df[result_arr].copy()

        df['weight'] = df_result_weight['s_price']*0
        df['weight'] += df_result_weight['s_score']*weight_cal2(my_score)
        df['weight'] += df_result_weight['s_alcohol']*0.5
        df['weight'] += df_result_weight['foods_result']*weight_cal2(my_food)
        df['weight'] += df_result_weight['re_result']*weight_cal2(my_review)

        df_sorted_by_values = df.sort_values(by='weight' ,ascending=False)
        result = df_sorted_by_values[:6]

        result_name = result['name'].to_list()
        result_price = result['price'].to_list()
        result_winery = result['winery'].to_list()
        result_alcohol = np.round(result['alcohol'].to_list(),1)  # 도수 반올림
        result_url = result['url'].to_list()

        #사진 url 뽑아오기
        img_url=[]
        headers = {'User-Agent': 'Mozilla/5.0'}
        for url in result_url :
            web = requests.get(url, headers=headers).content
            source = BeautifulSoup(web, 'html.parser')
            img_url.append(source.find_all('img',{'class':'image'})[0]['src'])



        result_data = zip(result_name,result_winery,result_price,result_alcohol,img_url,result_url)
        context = {'result_data': result_data}



        return render(request, 'wine_recommend/recommend_category_result.html',context)
