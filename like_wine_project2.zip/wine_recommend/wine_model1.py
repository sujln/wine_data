import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


#불용어 제거

nltk.download('stopwords')
stopwords = nltk.corpus.stopwords.words('english')

def cosine_func1(df,col_name,wine_index):

    #정규 표현식으로 영문만 남음
    only_english  = [ re.sub('[^a-zA-Z]', ' ',str(sentence)).lower() for sentence in df[col_name]]
    #토큰만들기
    col_tokenized = [ nltk.word_tokenize(item) for item in only_english ]
    #불용어 빼기
    no_stopwords = [ i for i in col_tokenized if i not in stopwords]
    #다시 합쳐주기
    final_review = [ ' '.join(item) for item in no_stopwords ]

    #Tfidf
    tfidf_vect = TfidfVectorizer()
    feature_vect = tfidf_vect.fit_transform(final_review)

    #코사인 유사도 분석 => 사용자가 입력한 와인과 전체
    similarity_simple_pair = cosine_similarity(feature_vect[wine_index], feature_vect)
    result_list = similarity_simple_pair.tolist()[0]
    df[f'{col_name}_result'] = result_list

    return df

def weight_cal1(df,df_result_weight,price,score,alcohol,food,review,my_alcohol,my_price):
    if my_price == "1":
        df['weight'] = df_result_weight['s_price']*price
    else:
        df['weight'] = df_result_weight['rev_s_price']*price

    df['weight']+=df_result_weight['s_score']*score

    if my_alcohol == "1":
        df['weight']+=df_result_weight['s_alcohol']*alcohol
    else:
        df['weight']+=df_result_weight['rev_s_alcohol']*alcohol

    df['weight']+=df_result_weight['foods_result']*food

    df['weight']+=df_result_weight['re_result']*review

    df_sorted_by_values = df.sort_values(by='weight' ,ascending=False)
    result_df = df_sorted_by_values[:6]
    return result_df
