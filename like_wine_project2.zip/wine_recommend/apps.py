from django.apps import AppConfig


class WineRecommendConfig(AppConfig):
    name = 'wine_recommend'
